# Bus Manager Indonesia – APK Android

Pembungkus (WebView) untuk https://bus-manager-indonesia-599819804913.us-west1.run.app/
dengan dua versi:

- **normal** – `id.busmanager.game`
- **mod** – `id.busmanager.game.mod` (ada tombol hijau `$` di kiri bawah untuk mengisi uang)

`minSdk 21` = Android 5.0 ke atas. Game butuh internet saat pertama kali membuka
(mengunduh aset); setelah itu bisa offline di Android 7.0+ (service worker).

## Cara membuat APK (tanpa install apa pun)

1. Buat repo baru di GitHub, upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis, sekitar 3–5 menit).
3. Unduh artifact `BusManager-normal` dan `BusManager-MOD-uang`, ekstrak zip, pasang `.apk`.
   Izinkan "Pasang dari sumber tidak dikenal" jika diminta.

Atau lewat Android Studio: buka folder ini → Build > Build APK(s), pilih variant
`normalDebug` / `modDebug`.

## Soal mod uang

Mod mencari field bernama money/cash/coin/uang/saldo/balance/… di `localStorage` game,
mengisinya, lalu memuat ulang. Jika panel melapor "tidak ditemukan", kirim daftar key yang
tampil agar pola `RX` di `app/src/mod/assets/mod.js` bisa disesuaikan.
Jika save game disimpan di IndexedDB atau hanya di memori, perlu penyesuaian ke nama
field aslinya.

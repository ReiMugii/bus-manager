(function () {
  if (window.__busMod) return;
  window.__busMod = true;

  // Kata kunci nama field yang dianggap "uang". Tambah kalau game memakai nama lain.
  var RX = /(money|cash|coin|uang|saldo|balance|duit|gold|fund|rupiah|idr|kas)/i;
  var NUM = /^-?\d+(\.\d+)?$/;
  var FLAG = '__busmod_target';

  function walk(o, amt, hits, path) {
    if (!o || typeof o !== 'object') return;
    Object.keys(o).forEach(function (k) {
      var v = o[k];
      if (typeof v === 'number' && RX.test(k)) { o[k] = amt; hits.push(path + k); }
      else if (typeof v === 'string' && RX.test(k) && NUM.test(v)) { o[k] = String(amt); hits.push(path + k); }
      else if (v && typeof v === 'object') walk(v, amt, hits, path + k + '.');
    });
  }

  function apply(amt) {
    var hits = [];
    for (var i = 0; i < localStorage.length; i++) {
      var key = localStorage.key(i);
      if (key === FLAG) continue;
      var raw = localStorage.getItem(key);
      var obj;
      try { obj = JSON.parse(raw); } catch (e) { obj = undefined; }
      if (obj === undefined) {
        if (RX.test(key) && NUM.test(raw)) { localStorage.setItem(key, String(amt)); hits.push(key); }
        continue;
      }
      if (typeof obj === 'number' && RX.test(key)) { localStorage.setItem(key, String(amt)); hits.push(key); }
      else if (obj && typeof obj === 'object') {
        var before = hits.length;
        walk(obj, amt, hits, key + '.');
        if (hits.length > before) localStorage.setItem(key, JSON.stringify(obj));
      }
    }
    return hits;
  }

  // Jika sebelumnya diminta, tulis ulang saat halaman ditutup supaya autosave game tidak menimpa.
  function reapply() {
    var t = localStorage.getItem(FLAG);
    if (t) apply(Number(t));
  }
  window.addEventListener('pagehide', reapply);
  window.addEventListener('beforeunload', reapply);

  // ---------- UI ----------
  var btn = document.createElement('div');
  btn.textContent = '$';
  btn.style.cssText = 'position:fixed;left:8px;bottom:8px;width:40px;height:40px;border-radius:20px;' +
    'background:#16a34a;color:#fff;font:700 20px/40px sans-serif;text-align:center;z-index:2147483647;' +
    'opacity:.75;box-shadow:0 2px 6px rgba(0,0,0,.5)';

  var panel = document.createElement('div');
  panel.style.cssText = 'position:fixed;left:8px;bottom:56px;width:260px;padding:12px;background:#111827;' +
    'color:#fff;font:14px sans-serif;border-radius:10px;z-index:2147483647;display:none;' +
    'box-shadow:0 4px 16px rgba(0,0,0,.6)';
  panel.innerHTML =
    '<div style="font-weight:700;margin-bottom:6px">MOD Uang</div>' +
    '<input id="__bm_amt" type="number" value="999999999" style="width:100%;box-sizing:border-box;padding:6px;margin-bottom:8px">' +
    '<button id="__bm_go" style="width:100%;padding:8px;background:#16a34a;color:#fff;border:0;border-radius:6px;font-weight:700">Isi uang &amp; muat ulang</button>' +
    '<div id="__bm_msg" style="margin-top:8px;font-size:12px;word-break:break-all;max-height:140px;overflow:auto"></div>';

  function mount() {
    if (!document.body) return setTimeout(mount, 300);
    document.body.appendChild(btn);
    document.body.appendChild(panel);
  }
  mount();

  btn.addEventListener('click', function () {
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  });

  panel.querySelector('#__bm_go').addEventListener('click', function () {
    var amt = Number(panel.querySelector('#__bm_amt').value) || 0;
    var msg = panel.querySelector('#__bm_msg');
    var hits = apply(amt);
    if (hits.length) {
      localStorage.setItem(FLAG, String(amt));
      msg.textContent = 'Terisi ' + hits.length + ' field. Memuat ulang...';
      setTimeout(function () { location.reload(); }, 600);
    } else {
      var keys = [];
      for (var i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
      msg.textContent = 'Field uang tidak ditemukan di localStorage. Key yang ada: ' +
        (keys.join(', ') || '(kosong)') + '. Mainkan dulu sampai ada save, lalu coba lagi.';
    }
  });
})();

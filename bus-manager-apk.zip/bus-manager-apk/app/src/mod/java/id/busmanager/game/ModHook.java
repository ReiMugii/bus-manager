package id.busmanager.game;

import android.webkit.WebView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Versi MOD: menyuntikkan panel "uang" (assets/mod.js) ke dalam game. */
final class ModHook {
    private static String script;

    private ModHook() { }

    static void onPageStarted(WebView view) { }

    static void onPageFinished(WebView view) {
        if (script == null) {
            try (InputStream in = view.getContext().getAssets().open("mod.js")) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                script = out.toString("UTF-8");
            } catch (Exception e) {
                return;
            }
        }
        view.evaluateJavascript(script, null);
    }
}

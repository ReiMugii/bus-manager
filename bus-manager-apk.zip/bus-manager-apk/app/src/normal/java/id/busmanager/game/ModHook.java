package id.busmanager.game;

import android.webkit.WebView;

/** Versi normal: tidak melakukan apa-apa. */
final class ModHook {
    private ModHook() { }

    static void onPageStarted(WebView view) { }

    static void onPageFinished(WebView view) { }
}
